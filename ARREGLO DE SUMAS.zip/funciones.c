// funciones.c

#include "funciones.h"

void suma(float* a, float* b, float* resultado) {
    *resultado = *a + *b;
}

void resta(float* a, float* b, float* resultado) {
    *resultado = *a - *b;
}

void multiplicacion(float* a, float* b, float* resultado) {
    *resultado = *a * *b;
}

void division(float* a, float* b, float* resultado) {
    if (*b != 0) {
        *resultado = *a / *b;
    } else {
        printf("Error: división para cero\n");
       
    }
}
