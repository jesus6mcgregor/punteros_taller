// funciones.h
#include "funciones.c"


void suma(float* a, float* b, float* resultado);
void resta(float* a, float* b, float* resultado);
void multiplicacion(float* a, float* b, float* resultado);
void division(float* a, float* b, float* resultado);



